# Thesis notebook check

Checked on 2026-11-02 in `V:\thesis\PINNeikonal-main - Copy\PINNeikonal-main`.

**Result: none of the five notebooks runs unchanged in the current local environment.** All fail at the first code cell because `google.colab` is unavailable. This is an environment/setup failure; it does not establish that the numerical solver is incorrect. Additional file and compatibility problems are listed below.

The notebooks and existing figures, data, and model weights were left unchanged. Full neural-network training and prediction could not be executed.

## Results by notebook

Cell numbers below count every notebook cell, including the opening Markdown cell, starting at 1.

| Notebook | Example | Result and additional findings |
| --- | --- | --- |
| `codes/script1.ipynb` | Smooth vertical velocity gradient | Blocked by Colab setup and missing dependencies. Inputs exist. Cell 14 uses `LineWidth`, a compatibility problem with modern Matplotlib. |
| `codes/script2.ipynb` | Transfer learning | Same setup/dependency blockers. Inputs and pretrained weights exist. Cell 15 uses `LineWidth` twice. |
| `codes/script3.ipynb` | Multiple-source surrogate | Same setup/dependency blockers. Comparison input exists and its zero-traveltime location matches the saved test source. Cell 12 uses `LineWidth`. |
| `codes/script4.ipynb` | Anisotropy and topography | Same setup/dependency blockers, plus missing `vz.npy` and `vx.npy` in cell 7. Cell 22 uses `LineWidth`. SciAnn installation is unpinned. |
| `codes/script5.ipynb` | Marmousi velocity model | Same setup/dependency blockers. Inputs and pretrained weights exist. Cell 15 uses `LineWidth`. |

## Blocking issues and recommended corrections

### 1. Google Colab setup cannot run locally

All five notebooks begin with:

```python
from google.colab import drive
drive.mount('/content/gdrive')
```

Executing this actual code produced `ModuleNotFoundError: No module named 'google'` for every notebook. Their next cell changes into an author's Google Drive path:

```text
/content/gdrive/My Drive/Colab Notebooks/Codes/PINN_isotropic_eikonal_R1
```

For local execution, skip or replace both setup cells and use this repository's `codes` directory as the working directory. The input, model, and figure paths are relative to `codes`, not the repository root.

### 2. Required packages are absent, and the documented stack is old

The usable default interpreter is Python 3.14.6. Actual import attempts failed for NumPy, pandas, Matplotlib, SciPy, TensorFlow, and SciAnn.

The README specifies TensorFlow 2.2.0 and SciAnn 0.5.4.0. TensorFlow 2.2.0 has no Python 3.14-compatible release, so merely running the notebook installation cells under this interpreter will not recreate the original environment. Reproducing the documented stack requires an older compatible Python environment, typically Python 3.7 or 3.8, with compatible supporting package versions. Alternatively, updating the notebooks to a newer stack requires API verification and numerical validation.

A registered Python 3.12 interpreter was also found, but attempting to launch it returned `Access is denied`; its packages could not be checked. No other usable interpreter or project environment was found in the inspected workspace.

`script4` installs SciAnn without a version pin, unlike the other four notebooks. Reproduction should use a consistent, verified environment rather than independently installing different SciAnn versions.

### 3. `script4` references velocity files that are not supplied

Cell 7 requests:

```python
velz = np.load('./inputs/vtiseam/model/vz.npy')
vz = velz[::50, ::50]
velx = np.load('./inputs/vtiseam/model/vx.npy')
vx = velx[::50, ::50]
```

Neither requested file exists. The folder supplies `vzcoarse.npy` and `vxcoarse.npy`, both already shaped `(201, 201)`, matching the notebook's grid and reference traveltimes.

The appropriate file/shape correction is to load these coarse arrays directly:

```python
vz = np.load('./inputs/vtiseam/model/vzcoarse.npy')
vx = np.load('./inputs/vtiseam/model/vxcoarse.npy')
```

Keeping the old `[::50, ::50]` slices after changing filenames would shrink each supplied array to `(5, 5)`, causing a grid-size mismatch. This correction was identified but not applied.

### 4. Loss plots use a legacy keyword spelling

All five notebooks pass `LineWidth=2` to `ax.semilogy`. Modern Matplotlib expects `linewidth=2` or `lw=2`; the mixed-case spelling can raise an unexpected-keyword/property error. Replace each active occurrence with `linewidth=2` when preparing a modern environment.

This is a compatibility finding from source inspection. Matplotlib is absent here, so the plotting cells were not executed. Existing notebook images were generated under an older Matplotlib version and do not verify present-day compatibility.

## Checks that passed

- All five notebook JSON files parsed successfully.
- All 94 ordinary Python code cells compiled without syntax errors.
- Seven shell-command cells compiled after IPython transformation. The five `cd` cells are notebook-specific shorthand, not ordinary Python statements.
- All referenced local input files exist except the two `script4` velocity files described above. All referenced output directories exist.
- All eight supplied NumPy files have readable headers and payload lengths consistent with their shapes. Their stored values are finite; velocity arrays are positive and traveltime arrays are nonnegative.
- All five fast-sweeping comparison arrays match their corresponding notebook grid sizes and contain zero traveltime at the configured source location. For `script3`, this uses the saved test source `(sx, sz) = (1.7, 4.2)`.
- Marmousi velocity and reference text files each contain 10,201 values, matching a `(101, 101)` grid. Velocities are positive, reference traveltimes are finite and nonnegative, and reference traveltime is zero at the source.
- Both supplied model-weight files have HDF5 signatures. Their internal weights and compatibility with a live SciAnn model were not verified.
- Independent standard-library calculations of the analytical reference formulas for `script1`, `script2`, and the saved `script3` test source produced finite, nonnegative traveltimes. The corresponding homogeneous factored-gradient identities agreed to floating-point precision. These were sanity checks of the formulas, not executions of the notebook numerical cells or trained PINNs.

The independent relative L2 errors of the supplied fast-sweeping arrays against the analytical references were approximately 2.023% for `script1`, 0.639% for `script2`, and 1.381% for `script3`. These are comparison-data checks, not new PINN accuracy measurements.

## What remains unverified

Full cell-by-cell notebook execution, SciAnn/TensorFlow API compatibility, loading model weights into the networks, training convergence, runtime, generated plots, and newly computed PINN errors require a compatible environment and a fresh run. Saved notebook outputs show historical executions, but cannot substitute for those checks on this machine.
